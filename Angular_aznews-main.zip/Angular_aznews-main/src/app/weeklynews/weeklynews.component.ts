import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weeklynews',
  templateUrl: './weeklynews.component.html',
  styleUrls: ['./weeklynews.component.css']
})
export class WeeklynewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
