import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indmain',
  templateUrl: './indmain.component.html',
  styleUrls: ['./indmain.component.css']
})
export class IndmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
