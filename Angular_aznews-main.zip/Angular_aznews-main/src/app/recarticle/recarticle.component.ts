import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recarticle',
  templateUrl: './recarticle.component.html',
  styleUrls: ['./recarticle.component.css']
})
export class RecarticleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
