import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weeklytop',
  templateUrl: './weeklytop.component.html',
  styleUrls: ['./weeklytop.component.css']
})
export class WeeklytopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
