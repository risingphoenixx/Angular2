import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trendingbody',
  templateUrl: './trendingbody.component.html',
  styleUrls: ['./trendingbody.component.css']
})
export class TrendingbodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
